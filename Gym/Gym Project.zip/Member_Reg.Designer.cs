﻿namespace Gym
{
    partial class Member_Reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Member_Reg));
            panel1 = new Panel();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            label10 = new Label();
            label11 = new Label();
            txtusername = new TextBox();
            fname = new TextBox();
            txtconfirmpass = new TextBox();
            weight = new TextBox();
            lname = new TextBox();
            height = new TextBox();
            txtpass = new TextBox();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox4 = new ComboBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            button5 = new Button();
            button1 = new Button();
            label17 = new Label();
            label18 = new Label();
            goal = new TextBox();
            Dob = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gold;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label5);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(181, 967);
            panel1.TabIndex = 17;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(-10, 191);
            label9.Name = "label9";
            label9.Size = new Size(197, 206);
            label9.TabIndex = 22;
            label9.Text = "L";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(-10, 602);
            label8.Name = "label8";
            label8.Size = new Size(207, 206);
            label8.TabIndex = 21;
            label8.Text = "X";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(-10, 397);
            label7.Name = "label7";
            label7.Size = new Size(207, 206);
            label7.TabIndex = 20;
            label7.Text = "E";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(41, 836);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(99, 111);
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(-10, 6);
            label5.Name = "label5";
            label5.Size = new Size(197, 206);
            label5.TabIndex = 17;
            label5.Text = "F";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.gold_muscle;
            pictureBox1.Location = new Point(776, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 94);
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(212, 54);
            label1.Name = "label1";
            label1.Size = new Size(571, 84);
            label1.TabIndex = 18;
            label1.Text = "REGISTRATION";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Gold;
            label2.Location = new Point(226, 210);
            label2.Name = "label2";
            label2.Size = new Size(97, 25);
            label2.TabIndex = 20;
            label2.Text = "First Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(596, 210);
            label3.Name = "label3";
            label3.Size = new Size(95, 25);
            label3.TabIndex = 21;
            label3.Text = "Last Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Gold;
            label4.Location = new Point(229, 358);
            label4.Name = "label4";
            label4.Size = new Size(168, 25);
            label4.TabIndex = 22;
            label4.Text = "DOB (yyyy-mm-dd)";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Gold;
            label6.Location = new Point(472, 358);
            label6.Name = "label6";
            label6.Size = new Size(69, 25);
            label6.TabIndex = 23;
            label6.Text = "Gender";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Gold;
            label10.Location = new Point(654, 358);
            label10.Name = "label10";
            label10.Size = new Size(139, 25);
            label10.TabIndex = 24;
            label10.Text = "Experience Level";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.Gold;
            label11.Location = new Point(229, 494);
            label11.Name = "label11";
            label11.Size = new Size(49, 25);
            label11.TabIndex = 25;
            label11.Text = "Gym";
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.FromArgb(255, 255, 192);
            txtusername.BorderStyle = BorderStyle.None;
            txtusername.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusername.Location = new Point(585, 686);
            txtusername.Multiline = true;
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(319, 46);
            txtusername.TabIndex = 26;
            // 
            // fname
            // 
            fname.BackColor = Color.FromArgb(255, 255, 192);
            fname.BorderStyle = BorderStyle.None;
            fname.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            fname.Location = new Point(229, 257);
            fname.Multiline = true;
            fname.Name = "fname";
            fname.Size = new Size(319, 46);
            fname.TabIndex = 27;
            // 
            // txtconfirmpass
            // 
            txtconfirmpass.BackColor = Color.FromArgb(255, 255, 192);
            txtconfirmpass.BorderStyle = BorderStyle.None;
            txtconfirmpass.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtconfirmpass.Location = new Point(585, 791);
            txtconfirmpass.Multiline = true;
            txtconfirmpass.Name = "txtconfirmpass";
            txtconfirmpass.Size = new Size(319, 46);
            txtconfirmpass.TabIndex = 28;
            // 
            // weight
            // 
            weight.BackColor = Color.FromArgb(255, 255, 192);
            weight.BorderStyle = BorderStyle.None;
            weight.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            weight.Location = new Point(654, 544);
            weight.Multiline = true;
            weight.Name = "weight";
            weight.Size = new Size(159, 46);
            weight.TabIndex = 29;
            // 
            // lname
            // 
            lname.BackColor = Color.FromArgb(255, 255, 192);
            lname.BorderStyle = BorderStyle.None;
            lname.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lname.Location = new Point(596, 257);
            lname.Multiline = true;
            lname.Name = "lname";
            lname.Size = new Size(319, 46);
            lname.TabIndex = 30;
            // 
            // height
            // 
            height.BackColor = Color.FromArgb(255, 255, 192);
            height.BorderStyle = BorderStyle.None;
            height.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            height.Location = new Point(472, 544);
            height.Multiline = true;
            height.Name = "height";
            height.Size = new Size(149, 46);
            height.TabIndex = 31;
            // 
            // txtpass
            // 
            txtpass.BackColor = Color.FromArgb(255, 255, 192);
            txtpass.BorderStyle = BorderStyle.None;
            txtpass.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtpass.Location = new Point(226, 791);
            txtpass.Multiline = true;
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(319, 46);
            txtpass.TabIndex = 32;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(255, 255, 192);
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(654, 406);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(209, 40);
            comboBox1.TabIndex = 33;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.FromArgb(255, 255, 192);
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FlatStyle = FlatStyle.Flat;
            comboBox2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(476, 406);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(140, 40);
            comboBox2.TabIndex = 34;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // comboBox4
            // 
            comboBox4.BackColor = Color.FromArgb(255, 255, 192);
            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.FlatStyle = FlatStyle.Flat;
            comboBox4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(229, 544);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(209, 40);
            comboBox4.TabIndex = 36;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.Gold;
            label12.Location = new Point(654, 506);
            label12.Name = "label12";
            label12.Size = new Size(106, 25);
            label12.TabIndex = 37;
            label12.Text = "Weight (lbs)";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = Color.Gold;
            label13.Location = new Point(472, 506);
            label13.Name = "label13";
            label13.Size = new Size(104, 25);
            label13.TabIndex = 38;
            label13.Text = "Height (cm)";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = Color.Gold;
            label14.Location = new Point(585, 752);
            label14.Name = "label14";
            label14.Size = new Size(156, 25);
            label14.TabIndex = 39;
            label14.Text = "Confirm Password";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = Color.Gold;
            label15.Location = new Point(226, 757);
            label15.Name = "label15";
            label15.Size = new Size(87, 25);
            label15.TabIndex = 40;
            label15.Text = "Password";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.ForeColor = Color.Gold;
            label16.Location = new Point(585, 642);
            label16.Name = "label16";
            label16.Size = new Size(94, 25);
            label16.TabIndex = 41;
            label16.Text = "UserName";
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.Gold;
            button5.Location = new Point(476, 865);
            button5.Name = "button5";
            button5.Size = new Size(112, 34);
            button5.TabIndex = 42;
            button5.Text = "REGISTER";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.Gold;
            button1.Location = new Point(453, 925);
            button1.Name = "button1";
            button1.Size = new Size(163, 34);
            button1.TabIndex = 43;
            button1.Text = "Back to LOGIN";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.ForeColor = Color.Gold;
            label17.Location = new Point(226, 930);
            label17.Name = "label17";
            label17.Size = new Size(216, 25);
            label17.TabIndex = 44;
            label17.Text = "Already have an Account?";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.ForeColor = Color.Gold;
            label18.Location = new Point(226, 642);
            label18.Name = "label18";
            label18.Size = new Size(48, 25);
            label18.TabIndex = 46;
            label18.Text = "Goal";
            // 
            // goal
            // 
            goal.BackColor = Color.FromArgb(255, 255, 192);
            goal.BorderStyle = BorderStyle.None;
            goal.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            goal.Location = new Point(226, 686);
            goal.Multiline = true;
            goal.Name = "goal";
            goal.Size = new Size(319, 46);
            goal.TabIndex = 45;
            // 
            // Dob
            // 
            Dob.BackColor = Color.FromArgb(255, 255, 192);
            Dob.BorderStyle = BorderStyle.None;
            Dob.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Dob.Location = new Point(229, 406);
            Dob.Multiline = true;
            Dob.Name = "Dob";
            Dob.Size = new Size(209, 46);
            Dob.TabIndex = 47;
            // 
            // Member_Reg
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(945, 971);
            Controls.Add(Dob);
            Controls.Add(label18);
            Controls.Add(goal);
            Controls.Add(label17);
            Controls.Add(button1);
            Controls.Add(button5);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(comboBox4);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(txtpass);
            Controls.Add(height);
            Controls.Add(lname);
            Controls.Add(weight);
            Controls.Add(txtconfirmpass);
            Controls.Add(fname);
            Controls.Add(txtusername);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Member_Reg";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Member_Reg";
            Load += Member_Reg_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label9;
        private Label label8;
        private Label label7;
        private PictureBox pictureBox2;
        private Label label5;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label10;
        private Label label11;
        private TextBox txtusername;
        private TextBox fname;
        private TextBox txtconfirmpass;
        private TextBox weight;
        private TextBox lname;
        private TextBox height;
        private TextBox txtpass;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox4;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Button button5;
        private Button button1;
        private Label label17;
        private Label label18;
        private TextBox goal;
        private TextBox Dob;
    }
}