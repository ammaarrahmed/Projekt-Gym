﻿namespace Gym
{
    partial class Login_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login_Page));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            txtusername = new TextBox();
            txtpassword = new TextBox();
            label3 = new Label();
            checkBoxShowPS = new CheckBox();
            button1 = new Button();
            button2 = new Button();
            label4 = new Label();
            button5 = new Button();
            panel1 = new Panel();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label5 = new Label();
            label6 = new Label();
            comboBox1 = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(317, 49);
            label1.Name = "label1";
            label1.Size = new Size(263, 84);
            label1.TabIndex = 6;
            label1.Text = "LOGIN";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.gold_muscle;
            pictureBox1.Location = new Point(586, 47);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 94);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Gold;
            label2.Location = new Point(291, 315);
            label2.Name = "label2";
            label2.Size = new Size(94, 25);
            label2.TabIndex = 8;
            label2.Text = "UserName";
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.FromArgb(255, 255, 192);
            txtusername.BorderStyle = BorderStyle.None;
            txtusername.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusername.Location = new Point(291, 352);
            txtusername.Multiline = true;
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(319, 46);
            txtusername.TabIndex = 9;
            // 
            // txtpassword
            // 
            txtpassword.BackColor = Color.FromArgb(255, 255, 192);
            txtpassword.BorderStyle = BorderStyle.None;
            txtpassword.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtpassword.Location = new Point(291, 491);
            txtpassword.Multiline = true;
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(319, 46);
            txtpassword.TabIndex = 11;
            txtpassword.TextChanged += txtpassword_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(291, 454);
            label3.Name = "label3";
            label3.Size = new Size(87, 25);
            label3.TabIndex = 10;
            label3.Text = "Password";
            // 
            // checkBoxShowPS
            // 
            checkBoxShowPS.AutoSize = true;
            checkBoxShowPS.Cursor = Cursors.Hand;
            checkBoxShowPS.FlatStyle = FlatStyle.Flat;
            checkBoxShowPS.ForeColor = Color.Gold;
            checkBoxShowPS.Location = new Point(448, 553);
            checkBoxShowPS.Name = "checkBoxShowPS";
            checkBoxShowPS.Size = new Size(157, 29);
            checkBoxShowPS.TabIndex = 12;
            checkBoxShowPS.Text = "Show Password";
            checkBoxShowPS.UseVisualStyleBackColor = true;
            checkBoxShowPS.CheckedChanged += checkBoxShowPS_CheckedChanged;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.Gold;
            button1.Location = new Point(388, 622);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 13;
            button1.Text = "Sign-In";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.Gold;
            button2.Location = new Point(388, 680);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 14;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Gold;
            label4.Location = new Point(373, 775);
            label4.Name = "label4";
            label4.Size = new Size(212, 25);
            label4.TabIndex = 15;
            label4.Text = "Do not have an Account?";
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.Gold;
            button5.Location = new Point(600, 770);
            button5.Name = "button5";
            button5.Size = new Size(112, 34);
            button5.TabIndex = 13;
            button5.Text = "Sign-Up";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gold;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label5);
            panel1.Location = new Point(1, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(181, 830);
            panel1.TabIndex = 16;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 72F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(11, 166);
            label9.Name = "label9";
            label9.Size = new Size(158, 166);
            label9.TabIndex = 22;
            label9.Text = "L";
            label9.Click += label9_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 72F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(11, 491);
            label8.Name = "label8";
            label8.Size = new Size(166, 166);
            label8.TabIndex = 21;
            label8.Text = "X";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 72F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(11, 332);
            label7.Name = "label7";
            label7.Size = new Size(166, 166);
            label7.TabIndex = 20;
            label7.Text = "E";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(43, 686);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(99, 111);
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 72F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(11, 24);
            label5.Name = "label5";
            label5.Size = new Size(158, 166);
            label5.TabIndex = 17;
            label5.Text = "F";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Gold;
            label6.Location = new Point(291, 180);
            label6.Name = "label6";
            label6.Size = new Size(119, 25);
            label6.TabIndex = 19;
            label6.Text = "Account Type";
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(255, 255, 192);
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(291, 227);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(209, 40);
            comboBox1.TabIndex = 20;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            comboBox1.SelectionChangeCommitted += comboBox1_SelectionChangeCommitted;
            // 
            // Login_Page
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(945, 837);
            Controls.Add(comboBox1);
            Controls.Add(label6);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(button2);
            Controls.Add(button5);
            Controls.Add(button1);
            Controls.Add(checkBoxShowPS);
            Controls.Add(txtpassword);
            Controls.Add(label3);
            Controls.Add(txtusername);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "Login_Page";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            TransparencyKey = Color.White;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private TextBox txtusername;
        private TextBox txtpassword;
        private Label label3;
        private CheckBox checkBoxShowPS;
        private Button button1;
        private Button button2;
        private Label label4;
        private Button button5;
        private Panel panel1;
        private Label label5;
        private PictureBox pictureBox2;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private ComboBox comboBox1;
    }
}

