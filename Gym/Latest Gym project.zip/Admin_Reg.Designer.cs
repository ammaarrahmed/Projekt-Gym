﻿namespace Gym
{
    partial class Admin_Reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Reg));
            pictureBox1 = new PictureBox();
            label17 = new Label();
            button1 = new Button();
            button5 = new Button();
            label16 = new Label();
            label14 = new Label();
            lname = new TextBox();
            txtconfirmpass = new TextBox();
            txtusername = new TextBox();
            label3 = new Label();
            label15 = new Label();
            txtpass = new TextBox();
            fname = new TextBox();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label5 = new Label();
            comboBox4 = new ComboBox();
            label11 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.gold_muscle;
            pictureBox1.Location = new Point(816, 37);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 94);
            pictureBox1.TabIndex = 120;
            pictureBox1.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.ForeColor = Color.Gold;
            label17.Location = new Point(285, 911);
            label17.Name = "label17";
            label17.Size = new Size(216, 25);
            label17.TabIndex = 119;
            label17.Text = "Already have an Account?";
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.Gold;
            button1.Location = new Point(512, 906);
            button1.Name = "button1";
            button1.Size = new Size(163, 34);
            button1.TabIndex = 118;
            button1.Text = "Back to LOGIN";
            button1.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.Gold;
            button5.Location = new Point(535, 846);
            button5.Name = "button5";
            button5.Size = new Size(112, 34);
            button5.TabIndex = 117;
            button5.Text = "REGISTER";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.ForeColor = Color.Gold;
            label16.Location = new Point(603, 429);
            label16.Name = "label16";
            label16.Size = new Size(94, 25);
            label16.TabIndex = 116;
            label16.Text = "UserName";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = Color.Gold;
            label14.Location = new Point(603, 659);
            label14.Name = "label14";
            label14.Size = new Size(156, 25);
            label14.TabIndex = 115;
            label14.Text = "Confirm Password";
            // 
            // lname
            // 
            lname.BackColor = Color.FromArgb(255, 255, 192);
            lname.BorderStyle = BorderStyle.None;
            lname.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lname.Location = new Point(603, 237);
            lname.Multiline = true;
            lname.Name = "lname";
            lname.Size = new Size(319, 46);
            lname.TabIndex = 114;
            // 
            // txtconfirmpass
            // 
            txtconfirmpass.BackColor = Color.FromArgb(255, 255, 192);
            txtconfirmpass.BorderStyle = BorderStyle.None;
            txtconfirmpass.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtconfirmpass.Location = new Point(603, 698);
            txtconfirmpass.Multiline = true;
            txtconfirmpass.Name = "txtconfirmpass";
            txtconfirmpass.Size = new Size(319, 46);
            txtconfirmpass.TabIndex = 113;
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.FromArgb(255, 255, 192);
            txtusername.BorderStyle = BorderStyle.None;
            txtusername.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusername.Location = new Point(603, 473);
            txtusername.Multiline = true;
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(319, 46);
            txtusername.TabIndex = 112;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Gold;
            label3.Location = new Point(603, 190);
            label3.Name = "label3";
            label3.Size = new Size(95, 25);
            label3.TabIndex = 111;
            label3.Text = "Last Name";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = Color.Gold;
            label15.Location = new Point(244, 664);
            label15.Name = "label15";
            label15.Size = new Size(87, 25);
            label15.TabIndex = 110;
            label15.Text = "Password";
            // 
            // txtpass
            // 
            txtpass.BackColor = Color.FromArgb(255, 255, 192);
            txtpass.BorderStyle = BorderStyle.None;
            txtpass.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtpass.Location = new Point(244, 698);
            txtpass.Multiline = true;
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(319, 46);
            txtpass.TabIndex = 108;
            // 
            // fname
            // 
            fname.BackColor = Color.FromArgb(255, 255, 192);
            fname.BorderStyle = BorderStyle.None;
            fname.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            fname.Location = new Point(236, 237);
            fname.Multiline = true;
            fname.Name = "fname";
            fname.Size = new Size(319, 46);
            fname.TabIndex = 107;
            fname.TextChanged += fname_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Gold;
            label2.Location = new Point(233, 190);
            label2.Name = "label2";
            label2.Size = new Size(97, 25);
            label2.TabIndex = 105;
            label2.Text = "First Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Gold;
            label1.Location = new Point(233, 37);
            label1.Name = "label1";
            label1.Size = new Size(571, 84);
            label1.TabIndex = 104;
            label1.Text = "REGISTRATION";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gold;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label5);
            panel1.Location = new Point(0, -14);
            panel1.Name = "panel1";
            panel1.Size = new Size(205, 998);
            panel1.TabIndex = 103;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(-10, 191);
            label9.Name = "label9";
            label9.Size = new Size(197, 206);
            label9.TabIndex = 22;
            label9.Text = "L";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(-10, 604);
            label8.Name = "label8";
            label8.Size = new Size(207, 206);
            label8.TabIndex = 21;
            label8.Text = "X";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(-10, 397);
            label7.Name = "label7";
            label7.Size = new Size(207, 206);
            label7.TabIndex = 20;
            label7.Text = "E";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(41, 836);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(99, 111);
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 90F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(-10, 35);
            label5.Name = "label5";
            label5.Size = new Size(197, 206);
            label5.TabIndex = 17;
            label5.Text = "F";
            // 
            // comboBox4
            // 
            comboBox4.BackColor = Color.FromArgb(255, 255, 192);
            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.FlatStyle = FlatStyle.Flat;
            comboBox4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(244, 479);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(272, 40);
            comboBox4.TabIndex = 122;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.Gold;
            label11.Location = new Point(244, 429);
            label11.Name = "label11";
            label11.Size = new Size(49, 25);
            label11.TabIndex = 121;
            label11.Text = "Gym";
            // 
            // Admin_Reg
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(945, 971);
            Controls.Add(comboBox4);
            Controls.Add(label11);
            Controls.Add(pictureBox1);
            Controls.Add(label17);
            Controls.Add(button1);
            Controls.Add(button5);
            Controls.Add(label16);
            Controls.Add(label14);
            Controls.Add(lname);
            Controls.Add(txtconfirmpass);
            Controls.Add(txtusername);
            Controls.Add(label3);
            Controls.Add(label15);
            Controls.Add(txtpass);
            Controls.Add(fname);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Admin_Reg";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin_Reg";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label17;
        private Button button1;
        private Button button5;
        private Label label16;
        private Label label14;
        private TextBox lname;
        private TextBox txtconfirmpass;
        private TextBox txtusername;
        private Label label3;
        private Label label15;
        private TextBox txtpass;
        private TextBox fname;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private Label label9;
        private Label label8;
        private Label label7;
        private PictureBox pictureBox2;
        private Label label5;
        private ComboBox comboBox4;
        private Label label11;
    }
}